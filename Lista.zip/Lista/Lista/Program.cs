﻿using System;
using System.Drawing;
using System.Dynamic;
using System.Runtime.Serialization;
using System.Windows.Markup;

class lista
{
    static void Main(string[] args)
    {
        DateTime DtAtual = DateTime.Now;
        while (true)
        {
            Console.Clear();
            Menu();
            var a = int.TryParse(Console.ReadLine(), out var opc);
            if (a)
            {
                switch (opc)
                {
                    case 0:
                        goto saida;

                    case 1:
                        Console.WriteLine("Digite o numero do inicio do intervalo:");
                        a = ulong.TryParse(Console.ReadLine(), out var inicio);
                        Console.WriteLine("Digite o numero do fim do intervalo:");
                        a = ulong.TryParse(Console.ReadLine(), out var fim);
                        Console.WriteLine(Opc1(inicio, fim).ToString("0.00"));
                        Console.ReadKey();
                        break;

                    case 2:
                        Console.Write("Digite seu nome: ");
                        string nome = Console.ReadLine();
                    data:;
                        Console.WriteLine("Digite a sua data de nascimento no formato \"dd/MM/aaaa\":");
                        a = DateTime.TryParse(Console.ReadLine(), out var aniver);

                        if (!a) { Console.WriteLine("Tente novamente."); goto data; }

                        if (VerificarAniversario(aniver, 21))
                        {
                            Console.WriteLine($"{nome}, você pode entrar na festa.");
                        }
                        else
                        {
                            Console.WriteLine($"{nome}, você NÃO pode entrar na festa.");
                        }
                        Console.ReadKey();
                        break;

                    case 3:
                        Console.Write("Digite a altura do trapézio: ");
                        a = double.TryParse(Console.ReadLine(), out var Altura);
                        Console.Write("Digite a base menor do trapézio: ");
                        a = double.TryParse(Console.ReadLine(), out var Bmenor);
                        Console.Write("Digite a base maior do trapézio: ");
                        a = double.TryParse(Console.ReadLine(), out var Bmaior);
                        Console.Write($"A area do trapézio é {Opc3(Altura, Bmenor, Bmaior)}");
                        Console.ReadKey();
                        break;

                    case 4:
                    salar:;
                        Console.Write("Digite o seu salário: ");
                        a = double.TryParse(Console.ReadLine(), out var salario);

                        if (Opc4(salario, 0) == -1) { Console.WriteLine("Tente novamente."); goto salar; }

                        if (salario >= 0 && salario <= 1500)
                        {
                            Console.WriteLine($"Seu salário líquido é de {Opc4(salario, 0).ToString("C2")}.\n" +
                                $"Sendo isento de imposto.\n" +
                                $"E com 10% de desconto da previdencia social de {Opc4(salario, 1).ToString("C2")}.");
                        }
                        if (salario >= 1500.01 && salario <= 3000)
                        {
                            Console.WriteLine($"Seu salário líquido é de {Opc4(salario, 0).ToString("C2")}.\n" +
                                $"Com um de imposto de {Opc4(salario, 2).ToString("C2")}.\n" +
                                $"E com 10% de desconto da previdencia social de {Opc4(salario, 1).ToString("C2")}.");
                        }
                        if (salario >= 3000.01 && salario <= 8000)
                        {
                            Console.WriteLine($"Seu salário líquido é de {Opc4(salario, 0).ToString("C2")}.\n" +
                                $"Com um de imposto de {Opc4(salario, 2).ToString("C2")}.\n" +
                                $"E com 10% de desconto da previdencia social de {Opc4(salario, 1).ToString("C2")}.");
                        }
                        if (salario > 8000)
                        {
                            Console.WriteLine($"Seu salário líquido é de {Opc4(salario, 0).ToString("C2")}.\n" +
                                $"Com um de imposto de {Opc4(salario, 2).ToString("C2")}.\n" +
                                $"E com 10% de desconto da previdencia social de {Opc4(salario, 1).ToString("C2")}.");
                        }
                        Console.ReadKey();
                        break;

                    case 5:
                    del:;
                        Console.WriteLine("Digite o valor de:");
                        Console.Write("A: ");
                        a = double.TryParse(Console.ReadLine(), out var A);
                        Console.Write("B: ");
                        a = double.TryParse(Console.ReadLine(), out var B);
                        Console.Write("C: ");
                        a = double.TryParse(Console.ReadLine(), out var C);
                        Console.WriteLine(delta(A, B, C));

                        if (Opc5(A, B, C, 1) == -0.001) { Console.WriteLine("Erro de calculo."); goto del; }

                        if (A == 0)
                        {
                            Console.WriteLine("Impossivel dividir por 0.");
                        }
                        Console.WriteLine($"O valor do X¹ é {Opc5(A, B, C, 1)}");
                        Console.WriteLine($"O valor do X² é {Opc5(A, B, C, 2)}");
                        Console.ReadKey();
                        break;

                    case 6:
                        Console.Write("Digite o valor do raio: ");
                        a = double.TryParse(Console.ReadLine(), out var raio);
                        Console.WriteLine($"O valor da area do círculo é {Opc6(raio).ToString("0.00")}");
                        Console.ReadKey();
                        break;

                    case 7:
                        Console.Write("Digite o valor do raio: ");
                        a = double.TryParse(Console.ReadLine(), out raio);
                        Console.WriteLine($"O valor da area do círculo é {Opc7(raio).ToString("0.00")}");

                        Console.ReadKey();
                        break;

                    case 8:
                        Console.Write("Digite seu peso: ");
                        a = double.TryParse(Console.ReadLine(), out var peso);
                        Console.Write("Digite sua altura: ");
                        a = double.TryParse(Console.ReadLine(), out var altura);
                        Console.WriteLine($"Seu IMC é de {Opc8(peso, altura).ToString("F3")}");
                        classificacaoIMC(peso, altura);
                        Console.ReadKey();
                        break;

                    case 9:
                        Console.Write("Digite um numero para verificar: ");
                        a = ulong.TryParse(Console.ReadLine(), out var numero);
                        if (Opc9(numero))
                        {
                            Console.WriteLine($"{numero} é perfeito.");
                        }
                        else
                        {
                            Console.WriteLine($"{numero} não é perfeito.");
                        }
                        Console.ReadKey();
                        break;

                    case 10:
                        double precoIngresso = 0;
                        Console.Write("Digite o numero de pessoas: ");
                        a = int.TryParse(Console.ReadLine(), out var NumPessoas);

                        DateTime[] idades = new DateTime[NumPessoas];
                        precoIngresso += Ingressos(idades, NumPessoas);

                        Console.WriteLine($"O valor total dos ingressos é de {precoIngresso.ToString("C2")}.");
                        Console.ReadKey();

                        break;

                    default:
                        Console.WriteLine("Opção ínvalida.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Tente novante.");
            }
        }
    saida:;
    }
    static void Menu()
    {
        Console.WriteLine("Digite um nùmero para ir para a opção:");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(
            "0 - Sair;\n" +
            "1 - Média de números ímpares;\n" +
            "2 - Informar se pode entrar na festa;\n" +
            "3 - Área do trapézio;\n" +
            "4 - Salário líquido;\n" +
            "5 - Bhaskara;\n" +
            "6 - Área de um círculo;\n" +
            "7 - Volume da esfera;\n" +
            "8 - Índice de Massa Corporal - IMC;\n" +
            "9 - Números perfeitos;\n" +
            "10 - Valor de ingressos;\n"
            );
        Console.ResetColor();
    }
    static double Opc1(ulong x, ulong y)
    {
        ulong soma = 0;
        ulong cont = 0;
        for (ulong i = x; i <= y; i++)
        {
            if (i % 2 != 0)
            {
                soma += i;
                cont++;
            }
        }
        return soma / cont;
    }
    static double Opc3(double Altura, double Bmenor, double Bmaior)
    {
        Console.Clear();
        return 0.5 * Altura * (Bmenor + Bmaior) / 2;
    }
    static double Opc4(double x, int opc)
    {
        double Previdencia = x * 0.10;
        if (x >= 0 && x <= 1500)
        {
            double salario = x - Previdencia;
            if (opc == 0) return salario;
            if (opc == 1) return Previdencia;
        }
        if (x >= 1500.01 && x <= 3000)
        {
            double Imp = (x - 1500) * 0.05;
            double salario = (x - Imp) - Previdencia;
            if (opc == 0) return salario;
            if (opc == 1) return Previdencia;
            if (opc == 2) return Imp;
        }
        if (x >= 3000.01 && x <= 8000)
        {
            double Imp = ((x - 3000) * 0.19) + (1500 * 0.05);
            double salario = (x - Imp) - Previdencia;
            if (opc == 0) return salario;
            if (opc == 1) return Previdencia;
            if (opc == 2) return Imp;

        }
        if (x > 8000)
        {
            double Imp = ((x - 8000) * 0.29) + (1500 * 0.05) + (5000 * 0.19);
            double salario = (x - Imp) - Previdencia;
            if (opc == 0) return salario;
            if (opc == 1) return Previdencia;
            if (opc == 2) return Imp;
        }
        return -1;
    }
    static double delta(double a, double b, double c)
    {
        return (Math.Pow(b, 2) + ((1 - 4) * (a * c)));
    }
    static double Opc5(double a, double b, double c, int opc)
    {
        if (delta(a, b, c) <= 0)
        {
            Console.WriteLine("Delta < 0.");
            return -0.001;
        }
        double raiz = Math.Sqrt(delta(a, b, c));
        double x1 = (-b + raiz) / (2 * a);
        double x2 = (-b - raiz) / (2 * a);
        if (opc == 1) return x1;
        if (opc == 2) return x2;
        return -0.001;
    }
    static double Opc6(double raio)
    {
        return Math.PI * Math.Pow(raio, 2);
    }
    static double Opc7(double raio)
    {
        return (4.0 / 3) * Math.PI * Math.Pow(raio, 3);
    }
    static double Opc8(double peso, double altura)
    {
        return peso / Math.Pow(altura, 2);
    }
    static void classificacaoIMC(double peso, double altura)
    {
        double IMC = Opc8(peso, altura);
        if (IMC < 18.5) Console.WriteLine("Ou seja, você está abaixo do peso.");

        else if (IMC >= 18.5 && IMC <= 24.9) Console.WriteLine("Ou seja, você está com o peso normal.");

        else if (IMC >= 25 && IMC <= 29.9) Console.WriteLine("Ou seja, você está com sobre peso.");

        else if (IMC >= 30 && IMC <= 34.9) Console.WriteLine("Atenção, você está com obesidade grau I.");

        else if (IMC >= 35 && IMC <= 39.9) Console.WriteLine("Atenção, você está com obesidade grau II.");

        else if (IMC >= 40) Console.WriteLine("Atençâo, você está com obesidade grau III.");
    }
    static bool Opc9(ulong numero)
    {
        ulong soma = 0;
        for (ulong i = 1; i < numero; i++)
        {
            if (numero % i == 0)
            {
                soma += i;
            }
        }
        if (soma == numero) return true;
        else return false;
    }
    static bool Ver_Aniver_Com_Intervalo(DateTime DtAniversario, DateTime DtAtual, int idade1, int idade2)
    {

        string anoAniversario = Convert.ToString(DtAniversario.Year);
        string mesAniversario = Convert.ToString(DtAniversario.Month);
        string diaAniversario = Convert.ToString(DtAniversario.Day);

        string anoAtual = Convert.ToString(DtAtual.Year);
        string mesAtual = Convert.ToString(DtAtual.Month);
        string diaAtual = Convert.ToString(DtAtual.Day);

        string IDADE1 = anoAniversario + mesAniversario + diaAniversario;
        string IDADE2 = anoAtual + mesAtual + diaAtual;

        int Atual1 = Convert.ToInt32(IDADE2);
        Console.WriteLine(IDADE1);
        int Aniversario1 = Convert.ToInt32(IDADE1);


        double anos = (Atual1 - Aniversario1) / 365.25;


        /*if (anos > idade1 && anos < idade2 && mesAniversario < mesAtual) { return true; }
        if (anos == idade1 || anos == idade2)
        {
            if (mesAniversario == mesAtual)
            {
                if (diaAniversario > diaAtual) return false;
                if (diaAniversario <= diaAtual){ return true; }
            }
        }*/
        return false;
    }
    static bool VerificarAniversario(DateTime DtAniversario, int idade)
    {
        DateTime DtAtual = DateTime.Now;
        int anos = DtAtual.Year - DtAniversario.Year;
        if (anos > idade) return true;
        if (anos == idade)
        {
            if (DtAniversario.Month < DtAtual.Month) { return true; }
            if (DtAniversario.Month == DtAtual.Month)
            {
                if (DtAniversario.Day <= DtAtual.Day) { return true;}
            }
        }
        return false;
    }
    static DateTime[] DTarray(int NumPessoas)
    {
        DateTime[] idades = new DateTime[NumPessoas];
        for (int i = 0; i < idades.Length; i++)
        {
            Console.Write($"Digite a idade da pessoa n° {i + 1}: ");
            var a = DateTime.TryParse(Console.ReadLine(), out idades[i]);
        }
        return idades;
    }
    static double Ingressos(DateTime[] Aniversario, int vs)
    {
        DateTime DtAtual = DateTime.Now;
        double soma = 0;
        Aniversario = DTarray(vs);
        for(int i = 0; i < Aniversario.Length;i++)
        {
            if (VerificarAniversario(Aniversario[i], 60)) soma += 13.50;
            else if (Ver_Aniver_Com_Intervalo(Aniversario[i], DtAtual, 5, 59)) soma += 27;
            else if (Ver_Aniver_Com_Intervalo(Aniversario[i], DtAtual, 0, 4)) soma += 0;
        }
        return soma;
    }

} 