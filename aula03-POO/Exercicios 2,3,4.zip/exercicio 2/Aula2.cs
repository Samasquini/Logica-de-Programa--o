﻿public class Conta
{
    public double Soma(double a, double b)
    {
        return a + b;
    }
    public double Subtrair(double a, double b)
    {
        return a - b;
    }
    public double Multplicar(double a, double b)
    {
        return a * b;
    }
    public double Dividir(double a, double b)
    {
        return a / b;
    }
}